// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Car.h"
#include "Components/PointLightComponent.h"
#include "Ligth.generated.h"

UCLASS()
class SEMAFORO_API ALigth : public AActor
{
    GENERATED_BODY()

public:

    /// <summary>
    /// Mesh
    /// </summary>
    UPROPERTY(EditAnywhere, Category = "Params")
    class UStaticMeshComponent* mesh;

    /// <summary>
    /// Temp
    /// </summary>
    UPROPERTY(EditAnywhere, Category = "Params")
    float TimeToGreen = 2.0f;

    /// <summary>
    /// Ligth
    /// </summary>
    UPROPERTY(EditAnywhere, Category = "Lights")
    class UPointLightComponent* RedLight;

    /// <summary>
    /// Ligth
    /// </summary>
    UPROPERTY(EditAnywhere, Category = "Lights")
    class UPointLightComponent* GreenLight;    

    // Sets default values for this actor's properties
    ALigth();

protected:
    // Called when the game starts or when spawned
    virtual void BeginPlay() override;

public:

    UFUNCTION()
    void OnOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

    UFUNCTION()
    void OnOverlapEnd(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);

    void AllowCar(ACar* Car);

    void ChangeToAllow();

    void ChangeLights(bool bIsGreen);

    // Called every frame
    virtual void Tick(float DeltaTime) override;

private:
       
    bool Allow;

    FTimerHandle TimerHandle;

    TArray<ACar*> CarsWaiting;
};
