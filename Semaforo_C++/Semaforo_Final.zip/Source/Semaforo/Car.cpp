// Fill out your copyright notice in the Description page of Project Settings.


#include "Car.h"

// Sets default values
ACar::ACar()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	mesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("mesh"));

	mesh->SetupAttachment(RootComponent);

}

// Called when the game starts or when spawned
void ACar::BeginPlay()
{
	if (StartTargetPoint && EndTargetPoint)
	{
		startLocation = StartTargetPoint->GetActorLocation();
		endLocation = EndTargetPoint->GetActorLocation();
	}

	currentTime = 0.0f;

	Super::BeginPlay();
	
}

// Called every frame
void ACar::Tick(float DeltaTime)
{
	canMove ? Movement(DeltaTime) : void();

	Super::Tick(DeltaTime);

}

void ACar::Movement(float DeltaTime)
{
	if (StartTargetPoint && EndTargetPoint)
	{
		currentTime += DeltaTime;
		float Alpha = FMath::Clamp(currentTime * speed / FVector::Distance(startLocation, endLocation), 0.0f, 50.0f);

		FVector NewLocation = FMath::Lerp(startLocation, endLocation, Alpha);

		SetActorLocation(NewLocation);

		if (Alpha >= 1.0f)
		{
			FVector Temp = startLocation;
			startLocation = endLocation;
			endLocation = Temp;
			currentTime = 0.0f;
		}
	}
}

