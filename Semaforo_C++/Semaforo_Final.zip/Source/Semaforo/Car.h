// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Engine/TargetPoint.h"
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Car.generated.h"

UCLASS()
class SEMAFORO_API ACar : public AActor
{
	GENERATED_BODY()
	
public:	

	///<summary>
	///Velocidad
	///	</summary>
	UPROPERTY(EditAnywhere, Category = "Parametros")
	float speed = 1000;

	///<summary>
	///Movimiento
	///	</summary>
	UPROPERTY(EditAnywhere, Category = "Parametros")
	bool canMove = true;

	///<summary>
	///Mesh
	///	</summary>
	UPROPERTY(EditAnywhere, Category = "Parametros")
	class UStaticMeshComponent* mesh;

	///<summary>
	///TargetPoint
	///	</summary>
	UPROPERTY(EditAnywhere, Category = "TargetPoints")
	class ATargetPoint* StartTargetPoint;

	///<summary>
	///TargetPoint
	///	</summary>
	UPROPERTY(EditAnywhere, Category = "TargetPoints")
	class ATargetPoint* EndTargetPoint;
	
	// Sets default values for this actor's properties
	ACar();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	void Movement(float);

private:
	
	FVector startLocation;
	FVector endLocation;

	float currentTime;

};
