// Fill out your copyright notice in the Description page of Project Settings.


#include "Ligth.h"
#include "Components/BoxComponent.h"

// Sets default values
ALigth::ALigth()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

    // Intancia y configurar el componente de colisionador
    UBoxComponent* BoxComponent = CreateDefaultSubobject<UBoxComponent>(TEXT("CollisionBox"));
    RootComponent = BoxComponent;
    BoxComponent->SetCollisionProfileName(TEXT("Trigger"));
    BoxComponent->OnComponentBeginOverlap.AddDynamic(this, &ALigth::OnOverlapBegin);
    BoxComponent->OnComponentEndOverlap.AddDynamic(this, &ALigth::OnOverlapEnd);


    // Instancia las dos luces
    RedLight = CreateDefaultSubobject<UPointLightComponent>(TEXT("RedLight"));
    RedLight->SetupAttachment(RootComponent);

    GreenLight = CreateDefaultSubobject<UPointLightComponent>(TEXT("GreenLight"));
    GreenLight->SetupAttachment(RootComponent);


    // Instancia la mesh
    mesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("mesh"));
    mesh->SetupAttachment(RootComponent);

}

// Called when the game starts or when spawned
void ALigth::BeginPlay()
{
	Super::BeginPlay();

    IsGreen = true;
	
    ChangeLights(IsGreen);
}

// Called every frame
void ALigth::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
    
    //Si el semaforo tiene permitido el paso, mira en la lista de espera del cohe y si hay alguno le permite esperar
    if (IsGreen)
    {
        if (CarsWaiting.Num() > 0)
        {
            AllowCar(CarsWaiting[0]);
        }
    }
}

void ALigth::OnOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
    ACar* Car = Cast<ACar>(OtherActor);

    //Un coche entra en el colider del semaforo
    if (Car)
    {
        //Se para el movimiento del coche antes de hacer nada
        Car-> canMove = false;

        //Si hay ya un coche en la lista de espera, el chcohe que ha entrado se a�ade a la lista de espera
        if (CarsWaiting.Num() > 0)
        {
            CarsWaiting.Add(Car);
        }
        else
        {
            //si no hay ningun coche en la lista de espera se comprueba si el semaforo permite el paso o no
            if (IsGreen)
            {
                //si lo permite activa el movimiento del coche, deja de permitir pasar a mas coches y cambia su luz a rojo
                Car->canMove = true;
                IsGreen = false;
                ChangeLights(false);
            }
            else 
            {
                //si no lo permite simplemente se a�ade el coche a la lista de espera
                CarsWaiting.Add(Car);
            }
                
        }
    }
}

void ALigth::OnOverlapEnd(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
    ACar* Car = Cast<ACar>(OtherActor);
    //Un coche sale del colider del semaforo
    if (Car)
    {
        //Se cambia la luz a verde
        ChangeLights(true);
        //Si hay algun chcoche esperando
        if (CarsWaiting.Num() > 0)
        {
            //Se llama al metdodo que activa el permiso en el semaforo, pero se le llama esperando "TimeToGreen" Segundos
            GetWorldTimerManager().SetTimer(TimerHandle, this, &ALigth::ChangeToGreen, TimeToGreen, false);
        }
        else 
        {
            ChangeToGreen();
        }
    }
}



void ALigth::ChangeToGreen()
{
    IsGreen = true;
}

void ALigth::AllowCar(ACar* Car) 
{
    Car->canMove = true;
    CarsWaiting.RemoveAt(0);
    IsGreen = false;
    ChangeLights(false);
}

void ALigth::ChangeLights(bool Green)
{
    RedLight->SetVisibility(!Green);
    GreenLight->SetVisibility(Green);
}
